<?php $__env->startSection('title', 'Daftar UMKM'); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .umkm-header { margin-bottom: 24px; display: flex; justify-content: space-between; align-items: flex-end; }
    .umkm-title { font-size: 28px; font-weight: 800; letter-spacing: -0.5px; }
    .umkm-desc { font-size: 13px; color: var(--text-secondary); margin-top: 4px; }
    
    .filter-container { display: flex; gap: 16px; align-items: center; margin-bottom: 24px; }
    .search-box { position: relative; flex: 1; max-width: 400px; }
    .search-box i { position: absolute; left: 16px; top: 50%; transform: translateY(-50%); color: var(--text-secondary); }
    .search-box input {
        width: 100%; background: var(--card-color); border: 1px solid var(--border-color);
        padding: 12px 16px 12px 40px; border-radius: 12px; color: #fff; font-size: 13px;
        outline: none; transition: border-color 0.2s;
    }
    .search-box input:focus { border-color: #555; }
    
    .limit-box { display: flex; align-items: center; gap: 8px; font-size: 13px; color: var(--text-secondary); }
    .limit-select {
        background: var(--card-color); border: 1px solid var(--border-color);
        color: #fff; padding: 8px 12px; border-radius: 8px; outline: none; cursor: pointer;
    }

    .table-card { background: var(--card-color); border: 1px solid var(--border-color); border-radius: 16px; overflow: hidden; }
    .umkm-table { width: 100%; border-collapse: collapse; }
    .umkm-table th {
        background: rgba(255,255,255,0.03); color: var(--text-secondary);
        font-size: 12px; font-weight: 600; text-transform: uppercase;
        padding: 16px 24px; text-align: left; border-bottom: 1px solid var(--border-color);
    }
    .umkm-table td { padding: 16px 24px; border-bottom: 1px solid var(--border-color); font-size: 14px; vertical-align: middle; }
    .umkm-table tbody tr { transition: background 0.2s; }
    .umkm-table tbody tr:hover { background: rgba(255,255,255,0.02); }
    
    .badge { padding: 4px 10px; border-radius: 6px; font-size: 11px; font-weight: 600; }
    .badge.sehat { background: rgba(74,222,128,0.1); color: #4ade80; }
    .badge.sedang { background: rgba(250,204,21,0.1); color: #facc15; }
    .badge.kritis { background: rgba(248,113,113,0.1); color: #f87171; }
    .badge.unknown { background: rgba(255,255,255,0.1); color: #a3a3a3; }
    
    .empty-state { text-align: center; padding: 60px 20px; color: var(--text-secondary); }
    .empty-state i { font-size: 48px; margin-bottom: 16px; opacity: 0.5; }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="umkm-header">
    <div>
        <h1 class="umkm-title">Daftar UMKM</h1>
        <p class="umkm-desc">Kelola dan pantau seluruh data UMKM yang terdaftar di ekosistem Anda.</p>
    </div>
</div>

<div class="filter-container">
    <div class="search-box">
        <i class="fa-solid fa-magnifying-glass"></i>
        <input type="text" id="liveSearch" placeholder="Cari berdasarkan nama atau sektor...">
    </div>
    
    <div class="limit-box">
        <span>Tampilkan baris:</span>
        <select class="limit-select" id="limitSelect" onchange="changeLimit(this.value)">
            <option value="25" <?php echo e($current_limit == '25' ? 'selected' : ''); ?>>25</option>
            <option value="50" <?php echo e($current_limit == '50' ? 'selected' : ''); ?>>50</option>
            <option value="100" <?php echo e($current_limit == '100' ? 'selected' : ''); ?>>100</option>
            <option value="250" <?php echo e($current_limit == '250' ? 'selected' : ''); ?>>250</option>
            <option value="500" <?php echo e($current_limit == '500' ? 'selected' : ''); ?>>500</option>
            <option value="all" <?php echo e($current_limit == 'all' ? 'selected' : ''); ?>>Semua</option>
        </select>
    </div>
</div>

<div class="table-card">
    <?php if(count($umkm_list) > 0): ?>
        <table class="umkm-table" id="umkmTable">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama UMKM</th>
                    <th>Sektor Usaha</th>
                    <th>Skor Terakhir</th>
                    <th>Status</th>
                    <th>Tanggal Terdaftar</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $umkm_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $umkm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $badgeClass = 'unknown';
                        if($umkm->overall_score !== null) {
                            if($umkm->overall_score >= 60) $badgeClass = 'sehat';
                            elseif($umkm->overall_score >= 40) $badgeClass = 'sedang';
                            else $badgeClass = 'kritis';
                        }
                    ?>
                    <tr>
                        <td style="color: var(--text-secondary);"><?php echo e($index + 1); ?></td>
                        <td style="font-weight: 600;"><?php echo e($umkm->nama_umkm); ?></td>
                        <td style="color: var(--text-secondary);"><?php echo e($umkm->sektor_usaha ?? '-'); ?></td>
                        <td>
                            <?php if($umkm->overall_score !== null): ?>
                                <span style="font-weight: 700; color: <?php echo e($umkm->overall_score >= 60 ? '#4ade80' : ($umkm->overall_score >= 40 ? '#facc15' : '#f87171')); ?>">
                                    <?php echo e(round($umkm->overall_score, 1)); ?>

                                </span>
                            <?php else: ?>
                                <span style="color: var(--text-secondary); font-size: 12px;">-</span>
                            <?php endif; ?>
                        </td>
                        <td><span class="badge <?php echo e($badgeClass); ?>"><?php echo e($umkm->health_category); ?></span></td>
                        <td style="color: var(--text-secondary); font-size: 12px;">
                            <?php echo e(\Carbon\Carbon::parse($umkm->created_at)->format('d M Y')); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        
        <div id="noResults" class="empty-state" style="display: none;">
            <i class="fa-solid fa-magnifying-glass"></i>
            <h3>Tidak ada hasil</h3>
            <p>Pencarian Anda tidak cocok dengan data UMKM mana pun.</p>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <i class="fa-solid fa-store-slash"></i>
            <h3>Belum ada UMKM</h3>
            <p>Tambahkan UMKM pertama Anda untuk mulai memantau.</p>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    // Fitur Change Limit (Reload)
    function changeLimit(val) {
        window.location.href = '?limit=' + val;
    }

    // Fitur Live Search DOM murni
    const searchInput = document.getElementById('liveSearch');
    const tableBody = document.querySelector('#umkmTable tbody');
    const noResults = document.getElementById('noResults');
    const table = document.getElementById('umkmTable');

    if(searchInput && tableBody) {
        searchInput.addEventListener('keyup', function() {
            let filter = this.value.toLowerCase();
            let rows = tableBody.querySelectorAll('tr');
            let visibleCount = 0;
            
            rows.forEach(row => {
                let name = row.querySelector('td:nth-child(2)').textContent.toLowerCase();
                let sector = row.querySelector('td:nth-child(3)').textContent.toLowerCase();
                
                if (name.includes(filter) || sector.includes(filter)) {
                    row.style.display = "";
                    visibleCount++;
                } else {
                    row.style.display = "none";
                }
            });
            
            // Tampilkan pesan kosong jika tidak ada baris yang cocok
            if(visibleCount === 0) {
                table.style.display = 'none';
                noResults.style.display = 'block';
            } else {
                table.style.display = 'table';
                noResults.style.display = 'none';
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sisehat\resources\views/pages/umkm-list.blade.php ENDPATH**/ ?>