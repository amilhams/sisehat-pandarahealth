<?php $__env->startSection('title', 'Evaluasi Kinerja - Pandara Health'); ?>

<?php $__env->startSection('styles'); ?>
<style>
    body { background-color: #0a0a0a; color: #fff; font-family: 'Inter', sans-serif; }
    .assessment-container { max-width: 700px; margin: 60px auto; padding: 0 20px; }
    
    .header-section { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 24px; border-bottom: 1px solid #333; padding-bottom: 20px; }
    .header-title { font-size: 32px; font-weight: 600; margin: 0; }
    .header-progress { color: #888; font-size: 14px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; }
    .header-subtitle { color: #888; font-size: 14px; margin-top: 16px; margin-bottom: 40px; }

    .identity-card { background: #151515; border: 1px solid #222; border-radius: 12px; padding: 32px; margin-bottom: 60px; }
    .identity-title-row { display: flex; align-items: center; gap: 12px; margin-bottom: 12px; }
    .identity-icon { color: #888; font-size: 20px; }
    .identity-title { font-size: 18px; font-weight: 600; }
    .identity-desc { color: #666; font-size: 14px; margin-bottom: 24px; }
    .identity-input { width: 100%; background: #000; border: 1px solid #333; border-radius: 8px; padding: 14px 18px; color: #fff; font-size: 16px; outline: none; }
    .identity-input::placeholder { color: #444; }

    .question-item { margin-bottom: 60px; }
    .question-text { font-size: 18px; line-height: 1.6; margin-bottom: 28px; font-weight: 400; }
    
    .scale-row { display: flex; gap: 12px; margin-bottom: 12px; }
    .scale-btn { flex: 1; height: 56px; display: flex; align-items: center; justify-content: center; background: #151515; border: 1px solid #222; border-radius: 8px; font-size: 18px; font-weight: 600; cursor: pointer; transition: all 0.2s; color: #fff; }
    .scale-btn:hover { border-color: #444; background: #1a1a1a; }
    .scale-btn.active { background: #fff; color: #000; border-color: #fff; }

    .scale-labels { display: flex; justify-content: space-between; font-size: 10px; font-weight: 700; color: #555; text-transform: uppercase; letter-spacing: 0.5px; }

    .submit-container { margin-top: 80px; padding-top: 40px; border-top: 1px solid #222; text-align: center; }
    .btn-submit { width: 100%; background: #fff; color: #000; border: none; border-radius: 8px; padding: 18px; font-size: 15px; font-weight: 700; cursor: pointer; transition: opacity 0.2s; text-transform: uppercase; letter-spacing: 1px; }
    .btn-submit:hover { opacity: 0.9; }
    .submit-footer { color: #444; font-size: 12px; margin-top: 24px; }

    footer { margin-top: 100px; padding: 40px 0; border-top: 1px solid #111; display: flex; justify-content: space-between; font-size: 11px; font-weight: 600; color: #444; text-transform: uppercase; letter-spacing: 1px; }
    .footer-links { display: flex; gap: 24px; }
    .footer-links a { color: #444; text-decoration: none; }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="assessment-container">
    <div class="header-section">
        <h1 class="header-title">Evaluasi Kinerja</h1>
        <div class="header-progress">0% SELESAI</div>
    </div>
    <p class="header-subtitle">Kuesioner performa bisnis karyawan <?php echo e($assessment->umkm->nama_umkm ?? 'Pandara Health'); ?>.</p>

    <div class="identity-card">
        <div class="identity-title-row">
            <i class="fa-solid fa-fingerprint identity-icon"></i>
            <span class="identity-title">Verifikasi Identitas</span>
        </div>
        <p class="identity-desc">Masukkan ID karyawan Anda untuk melanjutkan.</p>
        <input type="text" id="employee_code" class="identity-input" placeholder="PH-2024-XXX">
    </div>

    <form id="assessmentForm">
        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="question-item" data-question-id="<?php echo e($q->question_id); ?>">
            <p class="question-text"><?php echo e($index + 1); ?>. <?php echo e($q->pertanyaan); ?></p>
            <div class="scale-row">
                <?php for($i = 1; $i <= $q->max_score; $i++): ?>
                <div class="scale-btn" onclick="selectScale(this, '<?php echo e($q->question_id); ?>', '<?php echo e($i); ?>')"><?php echo e($i); ?></div>
                <?php endfor; ?>
            </div>
            <div class="scale-labels">
                <span>Rendah / Tidak Setuju</span>
                <span>Tinggi / Setuju</span>
            </div>
            <input type="hidden" name="answers[<?php echo e($q->question_id); ?>]" id="q_<?php echo e($q->question_id); ?>">
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="submit-container">
            <button type="submit" class="btn-submit">Kirim Jawaban</button>
            <p class="submit-footer">Data diproses secara rahasia dan anonim untuk keperluan audit internal.</p>
        </div>
    </form>

    <footer>
        <div>© 2024 <?php echo e($assessment->umkm->nama_umkm ?? 'PANDARA HEALTH'); ?></div>
        <div class="footer-links">
            <a href="#">Privasi</a>
            <a href="#">Bantuan</a>
        </div>
    </footer>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    function selectScale(element, questionId, value) {
        // Remove active from sibling buttons
        const row = element.parentElement;
        row.querySelectorAll('.scale-btn').forEach(btn => btn.classList.remove('active'));
        
        // Add active to clicked
        element.classList.add('active');
        
        // Set hidden input value
        const hiddenInput = document.getElementById('q_' + questionId);
        if (hiddenInput) {
            hiddenInput.value = value;
            hiddenInput.setAttribute('value', value);
        }
        
        updateProgress();
    }

    function updateProgress() {
        const total = <?php echo e($questions->count()); ?>;
        const inputs = Array.from(document.querySelectorAll('input[type="hidden"]'));
        const answered = inputs.filter(el => el.id.startsWith('q_') && el.value !== '').length;
        const pct = Math.round((answered / total) * 100);
        document.querySelector('.header-progress').innerText = pct + '% SELESAI';
    }

    document.getElementById('assessmentForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const employeeCode = document.getElementById('employee_code').value.trim();
        if (!employeeCode) {
            alert('Silakan masukkan ID Karyawan Anda.');
            return;
        }

        const formData = new FormData(this);
        const answers = {};
        let allAnswered = true;

        const inputs = Array.from(document.querySelectorAll('input[type="hidden"]'));
        inputs.filter(el => el.id.startsWith('q_')).forEach(input => {
            if (!input.value) {
                allAnswered = false;
            } else {
                const qId = input.id.replace('q_', '');
                answers[qId] = input.value;
            }
        });

        if (!allAnswered) {
            alert('Silakan jawab semua pertanyaan terlebih dahulu.');
            return;
        }

        fetch('<?php echo e(route('employee.assessment.submit', $token)); ?>', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            },
            body: JSON.stringify({
                employee_code: employeeCode,
                answers: answers
            })
        })
        .then(res => res.json())
        .then(data => {
            if (data.error) {
                alert(data.error);
            } else {
                alert(data.message);
                window.location.reload();
            }
        })
        .catch(err => {
            console.error("Terjadi kesalahan:", err);
            alert('Terjadi kesalahan saat mengirim jawaban.');
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.clean', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sisehat\resources\views/pages/employee-assessment.blade.php ENDPATH**/ ?>