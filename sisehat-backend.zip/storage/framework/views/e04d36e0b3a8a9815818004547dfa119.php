<?php $__env->startSection('title', 'Tautan Tidak Valid'); ?>

<?php $__env->startSection('styles'); ?>
<style>
    body { background-color: #0a0a0a; color: #fff; font-family: 'Inter', sans-serif; height: 100vh; display: flex; align-items: center; justify-content: center; text-align: center; }
    .error-container { max-width: 400px; padding: 40px; background: #151515; border: 1px solid #222; border-radius: 16px; }
    .error-icon { font-size: 48px; color: #f87171; margin-bottom: 24px; }
    .error-title { font-size: 20px; font-weight: 700; margin-bottom: 12px; }
    .error-text { color: #888; font-size: 14px; line-height: 1.6; }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="error-container">
    <i class="fa-solid fa-circle-exclamation error-icon"></i>
    <div class="error-title">Tautan Tidak Dapat Diakses</div>
    <div class="error-text"><?php echo e($message ?? 'Tautan ini mungkin sudah kadaluarsa atau tidak valid.'); ?></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.clean', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sisehat\sisehat\resources\views/pages/error-link.blade.php ENDPATH**/ ?>