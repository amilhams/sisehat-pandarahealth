<?php $__env->startSection('title', 'Rekomendasi Strategis'); ?>

<?php $__env->startSection('styles'); ?>
<style>
    /* ── Page Header ── */
    .rek-title { font-size: 36px; font-weight: 800; margin-bottom: 14px; letter-spacing: -0.5px; }

    .rek-select {
        appearance: none; background: var(--card-color);
        border: 1px solid var(--border-color); border-radius: 10px;
        padding: 10px 40px 10px 16px; color: #fff; font-size: 14px;
        font-family: 'Inter', sans-serif; cursor: pointer; outline: none;
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%23666' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E");
        background-repeat: no-repeat; background-position: right 14px center;
        margin-bottom: 20px; min-width: 220px;
    }

    .rek-meta-row { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 28px; }
    .rek-desc { font-size: 13px; color: var(--text-secondary); line-height: 1.7; max-width: 480px; }
    .badge-status {
        display: inline-flex; align-items: center; gap: 7px;
        background: var(--card-color); border: 1px solid var(--border-color);
        border-radius: 20px; padding: 7px 16px; font-size: 12px; font-weight: 600;
        color: #fff; white-space: nowrap;
    }
    .badge-status-dot { width: 8px; height: 8px; border-radius: 50%; background: #4ade80; }

    /* ── Main Grid ── */
    .rek-grid { display: grid; grid-template-columns: 1fr 1.6fr; gap: 24px; align-items: flex-start; }
    
    /* ── Left Column Sticky ── */
    .rek-left-col { position: sticky; top: 24px; }

    /* ── Left: Gauge Card ── */
    .gauge-card {
        background: var(--card-color); border: 1px solid var(--border-color);
        border-radius: 16px; padding: 28px 24px 24px;
        height: 100%; display: flex; flex-direction: column;
    }
    .gauge-card-header { display: flex; align-items: center; gap: 14px; margin-bottom: 60px; }
    .gauge-card-icon {
        width: 32px; height: 32px; border-radius: 8px;
        background: transparent; border: 1px solid rgba(255,255,255,0.1);
        display: flex; align-items: center; justify-content: center; flex-shrink: 0;
    }
    .gauge-card-icon i { color: #fff; font-size: 14px; }
    .gauge-card-title { font-size: 26px; font-weight: 600; line-height: 1.1; color: #fff; }
    .gauge-canvas-wrap { position: relative; margin: 0 auto 40px; width: 220px; height: 130px; }
    .gauge-center-text {
        position: absolute; bottom: 10px; left: 50%; transform: translateX(-50%);
        text-align: center; line-height: 1;
    }
    .gauge-pct { font-size: 52px; font-weight: 700; color: #fff; }
    .gauge-pct span { font-size: 24px; font-weight: 400; color: #aaa; margin-left: -5px; }
    .gauge-label { font-size: 12px; font-weight: 700; letter-spacing: 1px; color: #00d285; margin-top: 8px; }
    .gauge-stats { display: flex; justify-content: space-between; border-top: 1px solid #222; padding-top: 24px; margin-top: 40px; }
    .gauge-stat { flex: 1; }
    .gauge-stat:first-child { text-align: left; }
    .gauge-stat:last-child { text-align: right; }
    .gauge-stat-label { font-size: 12px; font-weight: 600; letter-spacing: 0.5px; color: #666; text-transform: uppercase; margin-bottom: 8px; }
    .gauge-stat-val { font-size: 20px; font-weight: 500; color: #fff; }
    .gauge-stat-val.green { color: #00d285; }
    .gauge-note { font-size: 12px; color: #666; line-height: 1.6; margin-top: auto; padding-top: 24px; font-weight: 400; }

    /* ── Right: Priority Cards ── */
    .prio-header { display: flex; align-items: center; gap: 10px; margin-bottom: 18px; }
    .prio-header-icon { font-size: 20px; color: #facc15; }
    .prio-header-title { font-size: 20px; font-weight: 700; }

    .prio-card {
        background: #141414; border: 1px solid var(--border-color);
        border-radius: 14px; padding: 20px 20px 16px; margin-bottom: 14px;
        border-left: 4px solid;
        position: relative; overflow: hidden;
    }
    .prio-card.high  { border-left-color: #f87171; background: rgba(248,113,113,.04); }
    .prio-card.warn  { border-left-color: #fb923c; background: rgba(251,146,60,.04); }
    .prio-card.med   { border-left-color: #facc15; background: rgba(250,204,21,.04); }
    .prio-card.low   { border-left-color: #4ade80; background: rgba(74,222,128,.04); }

    .prio-card-top { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px; }
    .prio-card-left { display: flex; align-items: center; gap: 12px; }
    .prio-icon-wrap {
        width: 36px; height: 36px; border-radius: 10px;
        display: flex; align-items: center; justify-content: center; flex-shrink: 0;
    }
    .prio-card.high  .prio-icon-wrap { background: rgba(248,113,113,.15); }
    .prio-card.med   .prio-icon-wrap { background: rgba(250,204,21,.12); }
    .prio-card.low   .prio-icon-wrap { background: rgba(74,222,128,.12); }
    .prio-card.high  .prio-icon-wrap i { color: #f87171; }
    .prio-card.warn  .prio-icon-wrap { background: rgba(251,146,60,.12); }
    .prio-card.warn  .prio-icon-wrap i { color: #fb923c; }
    .prio-card.med   .prio-icon-wrap i { color: #facc15; }
    .prio-card.low   .prio-icon-wrap i { color: #4ade80; }

    .prio-name { font-size: 14px; font-weight: 700; }
    .prio-badge {
        font-size: 10px; font-weight: 800; padding: 4px 10px;
        border-radius: 6px; letter-spacing: .5px; flex-shrink: 0;
    }
    .prio-badge.high { background: rgba(248,113,113,.2); color: #f87171; }
    .prio-badge.warn { background: rgba(251,146,60,.15); color: #fb923c; }
    .prio-badge.med  { background: rgba(250,204,21,.15); color: #facc15; }
    .prio-badge.low  { background: rgba(74,222,128,.15); color: #4ade80; }

    .prio-desc { font-size: 12px; color: var(--text-secondary); line-height: 1.65; margin-bottom: 14px; }
    .prio-actions { display: flex; gap: 8px; flex-wrap: wrap; }
    .prio-btn {
        font-size: 11px; font-weight: 600; padding: 7px 14px; border-radius: 8px;
        border: 1px solid var(--border-color); background: var(--card-color);
        color: var(--text-secondary); cursor: pointer; font-family: 'Inter', sans-serif;
        display: flex; align-items: center; gap: 6px; transition: all .2s;
    }
    .prio-btn:hover { background: #222; color: #fff; border-color: #555; }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="rek-title">Rekomendasi Strategis</div>


<div style="display: flex; gap: 12px;">
    <?php if(isset($all_umkms) && $all_umkms->count() > 1): ?>
        <select class="rek-select" onchange="window.location.href='?umkm_id=' + this.value">
            <?php $__currentLoopData = $all_umkms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($u->umkm_id); ?>" <?php echo e($selected_umkm_id == $u->umkm_id ? 'selected' : ''); ?>>
                    <?php echo e($u->nama_umkm); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    <?php else: ?>
        <select class="rek-select">
            <option><?php echo e(optional($assessment_info)->umkm->nama_umkm ?? 'Nama UMKM'); ?></option>
        </select>
    <?php endif; ?>

    <?php if(isset($assessment_history) && $assessment_history->count() > 0): ?>
        <select class="rek-select" onchange="window.location.href='?umkm_id=<?php echo e($selected_umkm_id); ?>&assessment_id=' + this.value">
            <?php $__currentLoopData = $assessment_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($hist->assessment_id); ?>" <?php echo e($selected_assessment_id == $hist->assessment_id ? 'selected' : ''); ?>>
                    Periode: <?php echo e(\Carbon\Carbon::parse($hist->assessment_date)->format('F Y')); ?> (Ke-<?php echo e($hist->sequence_in_month ?? 1); ?>)
                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    <?php endif; ?>
</div>


<div class="rek-meta-row">
    <p class="rek-desc">Berdasarkan analisis terbaru, berikut adalah tindakan yang disarankan untuk meningkatkan kesehatan organisasi secara keseluruhan. Prioritaskan area kritis terlebih dahulu.</p>
    <div class="badge-status">
        <?php
            $overallCat = strtoupper($health_score->category ?? '');
            $dotColor = '#fff';
            if ($overallCat == 'SANGAT_SEHAT') $dotColor = '#4ade80';
            elseif ($overallCat == 'SEHAT') $dotColor = '#818cf8';
            elseif ($overallCat == 'CUKUP_SEHAT') $dotColor = '#facc15';
            elseif ($overallCat == 'KURANG_SEHAT') $dotColor = '#f87171';
        ?>
        <span class="badge-status-dot" style="background: <?php echo e($dotColor); ?>"></span> Status: <?php echo e(str_replace('_', ' ', strtoupper($health_score->category ?? 'N/A'))); ?>

    </div>
</div>


<div class="rek-grid">

    
    <div class="rek-left-col">
        <div class="gauge-card">
        <div class="gauge-card-header">
            <div class="gauge-card-icon">
                <i class="fa-solid fa-gauge-high"></i>
            </div>
            <div class="gauge-card-title">Kesehatan<br>Keseluruhan</div>
        </div>

        <div class="gauge-canvas-wrap">
            <canvas id="gaugeChart" style="width:220px; height:130px;"></canvas>
            <div class="gauge-center-text">
                <div class="gauge-pct"><?php echo e(number_format($health_score->overall_score ?? 0, 0)); ?><span>%</span></div>
                <div class="gauge-label">SKOR AKTIF</div>
            </div>
        </div>

        <div class="gauge-stats">
            <div class="gauge-stat">
                <div class="gauge-stat-label">Target Capaian</div>
                <div class="gauge-stat-val">85%</div>
            </div>
            <div class="gauge-stat">
                <div class="gauge-stat-label">Status Saat Ini</div>
                <?php
                    $cat = strtoupper($health_score->category ?? '');
                    $catColor = '#fff';
                    if ($cat == 'SANGAT_SEHAT') $catColor = '#4ade80';
                    elseif ($cat == 'SEHAT') $catColor = '#818cf8';
                    elseif ($cat == 'CUKUP_SEHAT') $catColor = '#facc15';
                    elseif ($cat == 'KURANG_SEHAT') $catColor = '#f87171';
                ?>
                <div class="gauge-stat-val" style="color: <?php echo e($catColor); ?>;">
                    <?php echo e(str_replace('_', ' ', strtoupper($health_score->category ?? 'N/A'))); ?>

                </div>
            </div>
        </div>

        <p class="gauge-note">*Skor dihitung berdasarkan rata-rata 6 faktor kesehatan organisasi.</p>
        </div>
    </div>

    
    <div>
        <div class="prio-header">
            <span class="prio-header-icon">!</span>
            <span class="prio-header-title">Prioritas Perbaikan</span>
        </div>

        <?php $__currentLoopData = $recommendations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                // Map category level to priority styling
                $level = strtolower($rec->category_level);
                $prioClass = 'low';
                $prioText = 'RENDAH';
                $icon = 'fa-square-check';

                if ($level == 'kurang_sehat') {
                    $prioClass = 'high';
                    $prioText = 'KRITIS';
                    $icon = 'fa-triangle-exclamation';
                } elseif ($level == 'cukup_sehat') {
                    $prioClass = 'warn';
                    $prioText = 'WASPADA';
                    $icon = 'fa-circle-exclamation';
                } elseif ($level == 'sehat') {
                    $prioClass = 'med';
                    $prioText = 'SEHAT';
                    $icon = 'fa-circle-info';
                } elseif ($level == 'sangat_sehat') {
                    $prioClass = 'low';
                    $prioText = 'SANGAT SEHAT';
                    $icon = 'fa-circle-check';
                }

                // Match factor name from radar_chart
                $factorName = collect($radar_chart)->firstWhere('id', $rec->factor_id)['factor'] ?? 'Faktor ' . $rec->factor_id;
            ?>
            <div class="prio-card <?php echo e($prioClass); ?>">
                <div class="prio-card-top">
                    <div class="prio-card-left">
                        <div class="prio-icon-wrap">
                            <i class="fa-solid <?php echo e($icon); ?>"></i>
                        </div>
                        <div class="prio-name"><?php echo e($factorName); ?></div>
                    </div>
                    <span class="prio-badge <?php echo e($prioClass); ?>"><?php echo e($prioText); ?></span>
                </div>
                <p class="prio-desc"><?php echo e($rec->recommendation_text); ?></p>
                <?php if($rec->suggested_action): ?>
                <div class="prio-actions">
                    <button class="prio-btn"><i class="fa-solid fa-bolt"></i> <?php echo e($rec->suggested_action); ?></button>
                </div>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
const healthScore = <?php echo e(number_format($health_score->overall_score ?? 0, 0)); ?>;
let gaugeColor = '#f87171';
if (healthScore > 75) gaugeColor = '#4ade80';
else if (healthScore > 50) gaugeColor = '#818cf8';
else if (healthScore > 25) gaugeColor = '#facc15';

// Half-donut gauge chart
const gaugeCtx = document.getElementById('gaugeChart').getContext('2d');
new Chart(gaugeCtx, {
    type: 'doughnut',
    data: {
        datasets: [{
            data: [healthScore, 100 - healthScore],
            backgroundColor: [gaugeColor, '#222'],
            borderWidth: 0,
            borderRadius: 10,
            circumference: 180,
            rotation: 270
        }]
    },
    options: {
        responsive: false,
        maintainAspectRatio: false,
        cutout: '80%',
        plugins: { legend: { display: false }, tooltip: { enabled: false } }
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sisehat\sisehat\resources\views/pages/rekomendasi.blade.php ENDPATH**/ ?>