<?php $__env->startSection('title', 'Isi Asesmen: ' . $umkm->nama_umkm); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .stepper-container { max-width: 800px; margin: 40px auto; }
    
    /* Progress Bar */
    .progress-nav {
        display: flex;
        justify-content: space-between;
        margin-bottom: 40px;
        position: relative;
    }
    .progress-nav::before {
        content: '';
        position: absolute;
        top: 15px; left: 0; right: 0;
        height: 2px; background: #222;
        z-index: 1;
    }
    .progress-step {
        width: 32px; height: 32px;
        background: #151515; border: 2px solid #222;
        border-radius: 50%; display: flex;
        align-items: center; justify-content: center;
        font-size: 12px; font-weight: 700; color: #444;
        z-index: 2; position: relative;
        transition: all 0.3s ease;
    }
    .progress-step.active { border-color: #fff; color: #fff; background: #000; box-shadow: 0 0 15px rgba(255,255,255,0.1); }
    .progress-step.completed { border-color: #4ade80; background: #4ade80; color: #000; }

    /* Factor Card */
    .factor-card {
        background: var(--card-color);
        border: 1px solid var(--border-color);
        border-radius: 24px;
        padding: 40px;
        display: none; /* Hidden by default */
        animation: fadeIn 0.4s ease-out;
    }
    .factor-card.active { display: block; }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }

    .factor-header { margin-bottom: 32px; }
    .factor-title { font-size: 12px; font-weight: 800; color: var(--accent); text-transform: uppercase; letter-spacing: 2px; margin-bottom: 8px; }
    .factor-name { font-size: 32px; font-weight: 800; margin-bottom: 12px; color: #fff; }
    .factor-desc { font-size: 14px; color: var(--text-secondary); line-height: 1.6; }

    /* Questions */
    .question-box { margin-bottom: 40px; padding-top: 32px; border-top: 1px solid #222; }
    .question-text { font-size: 16px; font-weight: 500; margin-bottom: 20px; color: #fff; }

    /* Scale Buttons */
    .options-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; }
    .option-btn {
        background: #151515; border: 1px solid #222;
        border-radius: 12px; padding: 18px;
        color: var(--text-secondary); font-size: 13px; font-weight: 600;
        cursor: pointer; text-align: center; transition: all 0.2s;
        display: flex; align-items: center; justify-content: center;
        min-height: 60px;
    }
    .option-btn:hover { border-color: #444; background: #1a1a1a; }
    .option-btn.active { background: #fff; border-color: #fff; color: #000; }

    /* Navigation */
    .nav-footer { display: flex; justify-content: space-between; margin-top: 32px; }
    .btn-nav {
        padding: 14px 28px; border-radius: 12px; font-size: 14px; font-weight: 600;
        cursor: pointer; transition: all 0.2s; display: flex; align-items: center; gap: 10px;
    }
    .btn-prev { background: transparent; border: 1px solid #333; color: var(--text-secondary); }
    .btn-next { background: #fff; border: none; color: #000; }
    .btn-next:disabled { opacity: 0.3; cursor: not-allowed; }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="stepper-container">
    
    <div class="progress-nav">
        <?php $__currentLoopData = $factors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $factor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="progress-step <?php echo e($index === 0 ? 'active' : ''); ?>" id="step-dot-<?php echo e($index + 1); ?>">
                <?php echo e($index + 1); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <form id="multiStepForm">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="assessment_id" value="<?php echo e($assessment->assessment_id); ?>">
        
        <?php $globalQCount = 1; ?>
        <?php $__currentLoopData = $factors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $factor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $stepNum = $index + 1; ?>
        <div class="factor-card <?php echo e($index === 0 ? 'active' : ''); ?>" id="step-card-<?php echo e($stepNum); ?>" data-step="<?php echo e($stepNum); ?>">
            <div class="factor-header">
                <div class="factor-title">FAKTOR <?php echo e($stepNum); ?></div>
                <h2 class="factor-name"><?php echo e($factor->nama_factor); ?></h2>
                <p class="factor-desc"><?php echo e($factor->deskripsi ?? 'Analisis dimensi ini membantu memahami efektivitas operasional dan strategis UMKM Anda.'); ?></p>
            </div>

            <div class="questions-list">
                <?php $__currentLoopData = $factor->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="question-box" data-q-id="<?php echo e($q->question_id); ?>">
                    <p class="question-text"><?php echo e($globalQCount); ?>. <?php echo e($q->pertanyaan); ?></p>
                    
                    <?php
                        $options = null;
                        if ($globalQCount >= 1 && $globalQCount <= 5) {
                            $options = [1 => 'Tidak', 2 => 'Dalam Proses', 3 => 'Iya'];
                        } elseif ($globalQCount == 6) {
                            $options = [1 => 'Modal Sendiri', 2 => 'Keluarga', 3 => 'Bank/Kredit'];
                        }
                        $maxScore = $options ? 3 : ($q->max_score ?? 5);
                    ?>

                    <?php if($options): ?>
                        <div class="options-grid" style="grid-template-columns: repeat(3, 1fr);">
                            <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="option-btn <?php echo e((isset($existingResponses[$q->question_id]) && $existingResponses[$q->question_id] == $val) ? 'active' : ''); ?>" 
                                 onclick="selectOption(this, <?php echo e($q->question_id); ?>, <?php echo e($val); ?>)">
                                <?php echo e($label); ?>

                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        
                        <div class="options-grid" style="grid-template-columns: repeat(<?php echo e($maxScore); ?>, 1fr);">
                            <?php for($i = 1; $i <= $maxScore; $i++): ?>
                            <div class="option-btn <?php echo e((isset($existingResponses[$q->question_id]) && $existingResponses[$q->question_id] == $i) ? 'active' : ''); ?>" 
                                 onclick="selectOption(this, <?php echo e($q->question_id); ?>, <?php echo e($i); ?>)">
                                <?php echo e($i); ?>

                            </div>
                            <?php endfor; ?>
                        </div>
                        <div class="scale-labels" style="display: flex; justify-content: space-between; margin-top: 8px; font-size: 10px; color: #444; font-weight: 700; text-transform: uppercase;">
                            <span>Sangat Buruk</span>
                            <span>Sangat Baik</span>
                        </div>
                    <?php endif; ?>

                    <input type="hidden" name="answers[<?php echo e($q->question_id); ?>]" 
                           id="ans_<?php echo e($q->question_id); ?>" 
                           value="<?php echo e($existingResponses[$q->question_id] ?? ''); ?>"
                           class="answer-input">
                </div>
                <?php $globalQCount++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="nav-footer">
                <?php if($stepNum > 1): ?>
                    <button type="button" class="btn-nav btn-prev" onclick="changeStep(-1)">
                        <i class="fa-solid fa-arrow-left"></i> Sebelumnya
                    </button>
                <?php else: ?>
                    <div></div> 
                <?php endif; ?>

                <?php if($stepNum < count($factors)): ?>
                    <button type="button" class="btn-nav btn-next" onclick="changeStep(1)" id="next-btn-<?php echo e($stepNum); ?>">
                        Selanjutnya <i class="fa-solid fa-arrow-right"></i>
                    </button>
                <?php else: ?>
                    <button type="button" class="btn-nav btn-next" onclick="submitFinal()" style="background: #4ade80;">
                        Simpan & Selesai <i class="fa-solid fa-circle-check"></i>
                    </button>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    let currentStep = 1;
    const totalSteps = <?php echo e(count($factors)); ?>;

    function selectOption(element, qId, value) {
        const parent = element.parentElement;
        parent.querySelectorAll('.option-btn').forEach(btn => btn.classList.remove('active'));
        element.classList.add('active');
        
        document.getElementById('ans_' + qId).value = value;
        validateStep(currentStep);
    }

    function validateStep(step) {
        const currentCard = document.getElementById('step-card-' + step);
        const inputs = currentCard.querySelectorAll('.answer-input');
        let allFilled = true;
        
        inputs.forEach(input => {
            if (!input.value) allFilled = false;
        });

        const nextBtn = document.getElementById('next-btn-' + step);
        if (nextBtn) nextBtn.disabled = !allFilled;
        
        return allFilled;
    }

    function changeStep(delta) {
        if (delta > 0 && !validateStep(currentStep)) {
            alert('Mohon isi semua pertanyaan di halaman ini.');
            return;
        }

        // Autosave before moving
        if (delta > 0) saveProgress();

        // Update UI
        document.getElementById('step-card-' + currentStep).classList.remove('active');
        document.getElementById('step-dot-' + currentStep).classList.remove('active');
        if (delta > 0) document.getElementById('step-dot-' + currentStep).classList.add('completed');

        currentStep += delta;

        document.getElementById('step-card-' + currentStep).classList.add('active');
        document.getElementById('step-dot-' + currentStep).classList.add('active');
        
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    function saveProgress() {
        const formData = new FormData(document.getElementById('multiStepForm'));
        const assessmentId = formData.get('assessment_id');
        
        const answers = [];
        const currentCard = document.getElementById('step-card-' + currentStep);
        currentCard.querySelectorAll('.answer-input').forEach(input => {
            const qId = input.id.replace('ans_', '');
            if (input.value) {
                answers.push({ question_id: parseInt(qId), answer_value: parseInt(input.value) });
            }
        });

        if (answers.length > 0) {
            fetch('<?php echo e(route('api.responses.submit')); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                body: JSON.stringify({
                    assessment_id: assessmentId,
                    respondent_type: 'owner',
                    answers: answers
                })
            });
        }
    }

    function submitFinal() {
        if (!validateStep(currentStep)) {
            alert('Mohon isi semua pertanyaan sebelum menyelesaikan.');
            return;
        }
        
        saveProgress();
        
        const assessmentId = document.querySelector('input[name="assessment_id"]').value;
        
        fetch(`/assessment/finish/${assessmentId}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            }
        })
        .then(res => res.json())
        .then(data => {
            alert(data.message || 'Asesmen Anda telah berhasil disimpan!');
            window.location.href = '<?php echo e(route('assessment')); ?>';
        })
        .catch(err => {
            console.error('Error finalizing assessment:', err);
            alert('Terjadi kesalahan saat menyelesaikan asesmen.');
        });
    }

    // Initial validation for steps
    document.addEventListener('DOMContentLoaded', () => {
        for(let i=1; i<=totalSteps; i++) validateStep(i);
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sisehat\sisehat\resources\views/pages/fill-assessment.blade.php ENDPATH**/ ?>