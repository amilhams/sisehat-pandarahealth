<?php $__env->startSection('title', 'Masuk'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="auth-title">Selamat Datang</h1>
<p class="auth-subtitle">Masuk ke sistem analitik kesehatan Anda.</p>

<form method="POST" action="<?php echo e(route('login.post')); ?>">
    <?php echo csrf_field(); ?>

    
    <div class="field">
        <label class="field-label">Alamat Email</label>
        <div class="field-inner">
            <span class="field-icon"><i class="fa-regular fa-envelope"></i></span>
            <input type="email" name="email" class="field-input" placeholder="nama@email.com" autocomplete="email" value="<?php echo e(old('email')); ?>">
        </div>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span style="color: var(--danger); font-size: 12px; margin-top: 4px;"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="field">
        <div class="field-row">
            <label class="field-label">Kata Sandi</label>
            <a href="<?php echo e(route('profile.password')); ?>" class="forgot-link">Lupa Password?</a>
        </div>
        <div class="field-inner">
            <span class="field-icon"><i class="fa-solid fa-lock"></i></span>
            <input type="password" name="password" class="field-input" placeholder="••••••••" id="loginPassword">
            <span class="field-right" onclick="togglePass('loginPassword', this)">
                <i class="fa-regular fa-eye-slash"></i>
            </span>
        </div>
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span style="color: var(--danger); font-size: 12px; margin-top: 4px; display: block;"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php if(session('error')): ?>
            <span style="color: var(--danger); font-size: 12px; margin-top: 4px; display: block;"><?php echo e(session('error')); ?></span>
        <?php endif; ?>
    </div>

    <button type="submit" class="btn-submit">
        MASUK <i class="fa-solid fa-arrow-right"></i>
    </button>
</form>

<p class="auth-footer">
    Belum memiliki akun? <a href="<?php echo e(route('register')); ?>">Daftar Sekarang</a>
</p>

<div style="text-align: center; margin-top: 24px;">
    <a href="<?php echo e(route('welcome')); ?>" style="color: #737373; text-decoration: none; font-size: 13px; font-weight: 600;">
        <i class="fa-solid fa-arrow-left"></i> Kembali ke Beranda
    </a>
</div>

<script>
function togglePass(id, el) {
    const input = document.getElementById(id);
    const isHidden = input.type === 'password';
    input.type = isHidden ? 'text' : 'password';
    el.innerHTML = isHidden
        ? '<i class="fa-regular fa-eye"></i>'
        : '<i class="fa-regular fa-eye-slash"></i>';
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sisehat\resources\views/pages/login.blade.php ENDPATH**/ ?>