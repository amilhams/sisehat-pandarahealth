<?php $__env->startSection('title', 'Manajemen Asesmen'); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .page-header { margin-bottom: 32px; }
    .page-header h1 { font-size: 28px; font-weight: 700; margin-bottom: 8px; }
    .page-header p { color: var(--text-secondary); font-size: 14px; }

    .assessment-section {
        background: var(--card-color);
        border: 1px solid var(--border-color);
        border-radius: 16px;
        padding: 32px;
        margin-bottom: 24px;
    }

    .section-title { font-size: 18px; font-weight: 600; margin-bottom: 8px; }
    .section-subtitle { font-size: 13px; color: var(--text-secondary); margin-bottom: 24px; }

    /* Target UMKM Grid */
    .umkm-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 16px;
    }

    .umkm-card {
        background: #151515;
        border: 1px solid var(--border-color);
        border-radius: 12px;
        padding: 20px;
        display: flex;
        align-items: center;
        gap: 16px;
        cursor: pointer;
        transition: all 0.2s;
    }

    .umkm-card:hover { border-color: #444; background: #1a1a1a; }
    .umkm-card.active { border-color: #fff; background: #1a1a1a; }

    .radio-circle {
        width: 20px;
        height: 20px;
        border: 2px solid #444;
        border-radius: 50%;
        flex-shrink: 0;
        position: relative;
    }

    .umkm-card.active .radio-circle { border-color: #fff; }
    .umkm-card.active .radio-circle::after {
        content: '';
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 10px;
        height: 10px;
        background: #fff;
        border-radius: 50%;
    }

    .umkm-info h4 { font-size: 14px; font-weight: 600; margin-bottom: 4px; }
    .umkm-info p { font-size: 11px; color: var(--text-secondary); }

    .add-umkm-btn {
        background: transparent;
        border: 1px dashed var(--border-color);
        border-radius: 12px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 8px;
        color: var(--text-secondary);
        font-size: 12px;
        cursor: pointer;
        transition: all 0.2s;
    }

    .add-umkm-btn:hover { border-color: #666; color: #fff; background: rgba(255,255,255,0.02); }
    .add-umkm-btn i { font-size: 20px; }

    /* Form Elements */
    .form-group { margin-bottom: 24px; }
    .form-label { display: block; font-size: 11px; font-weight: 700; color: var(--text-secondary); text-transform: uppercase; margin-bottom: 12px; letter-spacing: 0.5px; }
    .form-input {
        width: 100%;
        background: #151515;
        border: 1px solid var(--border-color);
        border-radius: 8px;
        padding: 14px 16px;
        color: #fff;
        font-size: 14px;
        outline: none;
    }
    .form-input:focus { border-color: #555; }

    /* Scale Questions */
    .question-item { margin-bottom: 32px; }
    .question-text { font-size: 14px; font-weight: 500; margin-bottom: 16px; }
    .scale-labels { display: flex; justify-content: space-between; margin-bottom: 8px; }
    .scale-label { font-size: 10px; font-weight: 700; color: var(--text-secondary); text-transform: uppercase; }
    
    .scale-options {
        display: grid;
        grid-template-columns: repeat(5, 1fr);
        gap: 8px;
    }

    .scale-btn {
        background: #151515;
        border: 1px solid var(--border-color);
        border-radius: 8px;
        padding: 14px;
        color: var(--text-secondary);
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        text-align: center;
        transition: all 0.2s;
    }

    .scale-btn:hover { background: #222; border-color: #444; }
    .scale-btn.active { background: #fff; border-color: #fff; color: #000; }

    /* Binary Questions (Yes/No) */
    .binary-options {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 12px;
    }

    /* Footer */
    .assessment-footer {
        display: flex;
        justify-content: flex-end;
        align-items: center;
        gap: 24px;
        margin-top: 32px;
        padding-bottom: 40px;
    }

    .btn-cancel { color: var(--text-secondary); font-size: 14px; font-weight: 500; cursor: pointer; background: none; border: none; }
    .btn-submit {
        background: #fff;
        color: #000;
        border: none;
        border-radius: 8px;
        padding: 12px 24px;
        font-size: 13px;
        font-weight: 600;
        display: flex;
        align-items: center;
        gap: 8px;
        cursor: pointer;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1>Manajemen Asesmen</h1>
    <p>Konfigurasi dan distribusikan asesmen kesehatan organisasi.</p>
</div>

<form id="assessmentForm">
    <!-- 1. Pilih Target UMKM -->
    <div class="assessment-section">
        <h2 class="section-title">1. Pilih Target UMKM</h2>
        <p class="section-subtitle">Pilih UMKM atau departemen yang akan menjalani asesmen ini.</p>

        <div class="umkm-grid">
            <input type="hidden" name="umkm_id" id="selected_umkm_id" value="<?php echo e($hasUmkm ? $umkms->first()->umkm_id : ''); ?>">
            <?php if($hasUmkm): ?>
                <?php $__currentLoopData = $umkms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $umkm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="umkm-card <?php echo e($index === 0 ? 'active' : ''); ?>" onclick="selectUmkm(this, <?php echo e($umkm->umkm_id); ?>)">
                    <div class="radio-circle"></div>
                    <div class="umkm-info">
                        <h4><?php echo e($umkm->nama_umkm); ?></h4>
                        <p>ID: PND-<?php echo e(str_pad($umkm->umkm_id, 4, '0', STR_PAD_LEFT)); ?> • Sektor: <?php echo e($umkm->sektor_usaha ?? '-'); ?></p>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            <div class="add-umkm-btn" onclick="window.location='<?php echo e(route('tambah-umkm')); ?>'">
                <i class="fa-solid fa-circle-plus"></i>
                <span>Tambah UMKM Baru</span>
            </div>
        </div>
    </div>

    <!-- 2. Data Kapasitas Organisasi -->
    <div class="assessment-section">
        <h2 class="section-title">2. Data Kapasitas Organisasi</h2>
        <p class="section-subtitle">Isi data dan evaluasi awal dari sudut pandang pemilik usaha.</p>

        <div class="form-group">
            <label class="form-label">Jumlah Karyawan</label>
            <input type="number" name="jumlah_karyawan" id="jumlah_karyawan" class="form-input" placeholder="Contoh: 50">
        </div>
    </div>

    <!-- 3. Evaluasi Kesehatan Organisasi (Pemilik) -->
    <div class="assessment-section">
        <h2 class="section-title">3. Evaluasi Kesehatan Organisasi (Pemilik)</h2>
        <p class="section-subtitle">Berikan penilaian Anda terhadap kondisi internal organisasi saat ini.</p>

        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="question-item">
            <p class="question-text"><?php echo e($q->pertanyaan); ?></p>
            
            <?php if($q->max_score > 2): ?>
                <div class="scale-labels">
                    <span class="scale-label">Sangat Buruk / Kurang</span>
                    <span class="scale-label">Sangat Baik / Cukup</span>
                </div>
                <div class="scale-options" style="grid-template-columns: repeat(<?php echo e($q->max_score); ?>, 1fr);">
                    <?php for($i = 1; $i <= $q->max_score; $i++): ?>
                        <div class="scale-btn" onclick="selectScale(this, <?php echo e($q->question_id); ?>, <?php echo e($i); ?>)"><?php echo e($i); ?></div>
                    <?php endfor; ?>
                </div>
            <?php else: ?>
                <div class="binary-options">
                    <div class="scale-btn" onclick="selectScale(this, <?php echo e($q->question_id); ?>, 2)">Ya</div>
                    <div class="scale-btn" onclick="selectScale(this, <?php echo e($q->question_id); ?>, 1)">Tidak</div>
                </div>
            <?php endif; ?>
            <input type="hidden" name="answers[<?php echo e($q->question_id); ?>]" id="ans_<?php echo e($q->question_id); ?>">
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="assessment-footer">
        <button type="button" class="btn-cancel">Batal</button>
        <button type="submit" class="btn-submit">
            Generate Assessment <i class="fa-solid fa-circle-check"></i>
        </button>
    </div>
</form>

<!-- Modal / Link Result Area -->
<div id="resultArea" style="display:none; margin-top: 32px; padding: 24px; background: #1a1a1a; border: 1px solid #333; border-radius: 12px;">
    <h3 style="font-size:16px; font-weight:600; margin-bottom:12px;">Link Asesmen Berhasil Dibuat</h3>
    <p style="font-size:13px; color:var(--text-secondary); margin-bottom:20px;">Bagikan tautan ini kepada karyawan Anda untuk mulai mengumpulkan data.</p>
    <div style="display:flex; gap:12px;">
        <input type="text" id="generatedLink" class="form-input" readonly style="flex:1;">
        <button class="btn-submit" onclick="copyLink()">Salin Link</button>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    function selectUmkm(element, id) {
        document.querySelectorAll('.umkm-card').forEach(card => card.classList.remove('active'));
        element.classList.add('active');
        document.getElementById('selected_umkm_id').value = id;
    }

    function selectScale(element, questionId, value) {
        // Handle sibling options
        const parent = element.parentElement;
        parent.querySelectorAll('.scale-btn').forEach(btn => btn.classList.remove('active'));
        element.classList.add('active');
        
        if (questionId && value) {
            document.getElementById('ans_' + questionId).value = value;
        }
    }

    document.getElementById('assessmentForm').addEventListener('submit', function(e) {
        e.preventDefault();
        console.log("Tombol ditekan, memulai proses generate...");
        
        const umkmId = document.getElementById('selected_umkm_id').value;
        const jumlahKaryawan = document.getElementById('jumlah_karyawan').value;
        
        if (!umkmId) { alert('Silakan pilih UMKM terlebih dahulu.'); return; }
        if (!jumlahKaryawan) { alert('Silakan isi Jumlah Karyawan terlebih dahulu.'); return; }

        console.log("Validasi JS lolos, mengirim request ke server...");
        const submitBtn = document.querySelector('.btn-submit');
        submitBtn.innerHTML = 'Memproses... <i class="fa-solid fa-spinner fa-spin"></i>';
        submitBtn.disabled = true;

        // Submit initial data to generate assessment
        fetch('<?php echo e(route('assessment.generate')); ?>', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            },
            body: JSON.stringify({
                umkm_id: umkmId,
                jumlah_karyawan: jumlahKaryawan
            })
        })
        .then(res => res.json())
        .then(data => {
            console.log("Server Response:", data); // Debugging
            
            if (data.errors) {
                let errorMsg = "Terjadi kesalahan validasi:\n";
                for (let key in data.errors) {
                    errorMsg += "- " + data.errors[key][0] + "\n";
                }
                alert(errorMsg);
            } else if (data.exception) {
                alert("Server Error: " + data.message + "\nFile: " + data.file + "\nLine: " + data.line);
            } else if (data.error) {
                alert(data.error);
            } else if (data.employee_link) {
                const linkArea = document.getElementById('resultArea');
                const linkInput = document.getElementById('generatedLink');
                
                linkArea.style.display = 'block';
                linkInput.value = data.employee_link;
                
                if (data.data && data.data.assessment_id) {
                    submitOwnerAnswers(data.data.assessment_id);
                }
                
                window.scrollTo({ top: linkArea.offsetTop - 100, behavior: 'smooth' });
            } else {
                alert("Server mengembalikan respons yang tidak terduga:\n\n" + JSON.stringify(data, null, 2));
            }
        })
        .catch(err => {
            console.error("Terjadi error fetch:", err);
            alert("Terjadi kesalahan jaringan atau server: " + err.message);
        })
        .finally(() => {
            const submitBtn = document.querySelector('.btn-submit');
            submitBtn.innerHTML = 'Generate Assessment <i class="fa-solid fa-circle-check"></i>';
            submitBtn.disabled = false;
        });
    });

    function submitOwnerAnswers(assessmentId) {
        const answers = [];
        const answerInputs = document.querySelectorAll('input[id^="ans_"]');
        
        answerInputs.forEach(input => {
            const questionId = input.id.replace('ans_', '');
            const val = input.value;
            if (val) {
                answers.push({ question_id: parseInt(questionId), answer_value: parseInt(val) });
            }
        });

        if (answers.length > 0) {
            fetch('<?php echo e(route('api.responses.submit')); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                body: JSON.stringify({
                    assessment_id: assessmentId,
                    respondent_type: 'owner',
                    answers: answers
                })
            })
            .then(res => res.json())
            .then(data => console.log("Owner Answers Response:", data))
            .catch(err => console.error("Owner Answers Error:", err));
        }
    }

    function copyLink() {
        const copyText = document.getElementById("generatedLink");
        copyText.select();
        copyText.setSelectionRange(0, 99999);
        navigator.clipboard.writeText(copyText.value);
        alert("Link berhasil disalin ke clipboard!");
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sisehat\resources\views/pages/assessment.blade.php ENDPATH**/ ?>