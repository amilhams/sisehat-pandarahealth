<?php $__env->startSection('title', 'Daftar'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="auth-title">Buat Akun</h1>
<p class="auth-subtitle">Daftarkan diri Anda untuk mengakses sistem<br>analitik klinis.</p>

<form method="POST" action="<?php echo e(route('register.post')); ?>">
    <?php echo csrf_field(); ?>

    
    <div class="field">
        <label class="field-label">Nama Lengkap</label>
        <div class="field-inner">
            <span class="field-icon"><i class="fa-regular fa-user"></i></span>
            <input type="text" name="name" class="field-input" placeholder="Contoh: Dr. Budi Santoso" autocomplete="name" value="<?php echo e(old('name')); ?>">
        </div>
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span style="color: var(--danger); font-size: 12px; margin-top: 4px;"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="field">
        <label class="field-label">Email</label>
        <div class="field-inner">
            <span class="field-icon"><i class="fa-regular fa-envelope"></i></span>
            <input type="email" name="email" class="field-input" placeholder="email@email.com" autocomplete="email" value="<?php echo e(old('email')); ?>">
        </div>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span style="color: var(--danger); font-size: 12px; margin-top: 4px;"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="field">
        <label class="field-label">Jenis Kelamin</label>
        <div style="display: flex; gap: 20px; margin-top: 8px;">
            <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; color: white;">
                <input type="radio" name="gender" value="laki-laki" <?php echo e(old('gender') == 'laki-laki' ? 'checked' : ''); ?> required>
                Laki-laki
            </label>
            <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; color: white;">
                <input type="radio" name="gender" value="perempuan" <?php echo e(old('gender') == 'perempuan' ? 'checked' : ''); ?>>
                Perempuan
            </label>
        </div>
        <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span style="color: var(--danger); font-size: 12px; margin-top: 4px;"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="field">
        <label class="field-label">Kata Sandi</label>
        <div class="field-inner">
            <span class="field-icon"><i class="fa-solid fa-lock"></i></span>
            <input type="password" name="password" class="field-input" placeholder="••••••••" id="regPassword">
        </div>
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span style="color: var(--danger); font-size: 12px; margin-top: 4px;"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="field">
        <label class="field-label">Konfirmasi Kata Sandi</label>
        <div class="field-inner">
            <span class="field-icon"><i class="fa-solid fa-lock-open"></i></span>
            <input type="password" name="password_confirmation" class="field-input" placeholder="••••••••" id="regPasswordConfirm">
        </div>
    </div>

    <button type="submit" class="btn-submit">
        DAFTAR <i class="fa-solid fa-arrow-right"></i>
    </button>
</form>

<p class="auth-footer">
    Sudah punya akun? <a href="<?php echo e(route('login')); ?>">Masuk</a>
</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sisehat\resources\views/pages/register.blade.php ENDPATH**/ ?>